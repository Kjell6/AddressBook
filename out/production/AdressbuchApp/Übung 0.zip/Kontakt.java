import java.util.LinkedList;
import java.util.List;
/**
 * Datenklasse für einen Kontakt mit Vorname, Nachname
 * und Adresse (Straße, Postleitzahl, Stadt und Land).
 *
 * @author Kjell Behrends
 * @author Julian Latendorf
 */

public class Kontakt {
    String vorname;
    String nachname;
    String strasse;
    String postleitzahl;
    String stadt;
    String land;

    /**
     * Erstellt ein neues Kontaktobjekt mit den angegebenen Daten.
     *
     * @param vname der Vorname des Kontakts
     * @param nname der Nachname des Kontakts
     * @param str die Straße des Kontakts
     * @param plz die Postleitzahl des Kontakts
     * @param stdt die Stadt des Kontakts
     * @param lnd das Land des Kontakts
     */

    public Kontakt(String vname, String nname, String str, String plz, String stdt, String lnd) {
        this.vorname = vname;
        this.nachname = nname;
        this.strasse = str;
        this.postleitzahl = plz;
        this.stadt = stdt;
        this.land = lnd;
    }


    /**
     * Gibt eine formatierte Zeichenfolge zurück, die die Informationen dieses Kontakts enthält.
     * Die Informationen werden in diesem Format angezeigt:
     * Vorname Nachname, Straße, Postleitzahl Stadt, Land.
     *
     * @return formatierte Zeichenfolge
     */
    public String toString() {
        return String.format("%s %s, %s, %s %s, %s",
                this.vorname, this.nachname, this.strasse,
                this.postleitzahl, this.stadt, this.land);
    }
}
