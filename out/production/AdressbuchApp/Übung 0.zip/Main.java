/**
 * Erstellt einige Kontaktobjekte, fügt sie einem Adressbuch hinzu
 * und gibt dann die Inhalte des Adressbuchs aus. Sucht und Sortiet das Adressbuch.
 *
 * @author Kjell Behrends
 * @author Julian Latendorf
 */

public class Main {
    
    public static void main(String[] args) {
        Kontakt marc = new Kontakt("Marc", "Legler", "Louise-Wagner-Straße 6",
                "23701", "Eutin", "Deutschland");
        Kontakt bernie = new Kontakt("Bernie", "Kappler", "Arndt Straße 11",
                "23566", "Lübeck", "Deutschland");
        Kontakt lukas = new Kontakt("Lukas", "Wrangel", "Pablo Straße 35",
                "110110", "Bogota", "Kolumbien");
        Kontakt obama = new Kontakt("Barack", "Obama", "Pennsylvania Avenue 6",
                "20501", "Washington D.C", "USA");

        Adressbuch meinAdressbuch = new Adressbuch();
        meinAdressbuch.addKontakt(marc);
        meinAdressbuch.addKontakt(bernie);
        meinAdressbuch.addKontakt(lukas);
        meinAdressbuch.addKontakt(obama);

        System.out.println(meinAdressbuch);
        System.out.println(meinAdressbuch.searchKontakte("Bernie"));
        System.out.println(meinAdressbuch.sortKontakte());
    }

}
